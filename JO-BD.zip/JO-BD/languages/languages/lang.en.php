<?php
/* 
------------------
Language: English
------------------
*/

$lang = array();

$lang['Title'] = 'JO Blood Donations';

$lang['JO-BD'] = 'JO-BD';
$lang['Home'] = 'Home';
$lang['About_App'] = 'About App';
$lang['Contact_Us'] = 'Contact Us';
$lang['Admin_Login'] = 'Admin Login';
$lang['Center_Login'] = 'Center Login';
$lang['Welcome'] = 'Welcome To JO-BD';
$lang['Cutomer_Login'] = 'Customer Login';
$lang['Login_Info'] = 'Please login with your Username and Password.';
$lang['Login'] = 'Login';
$lang['Signup'] = 'Signup';
$lang['Forget_Password'] = 'Forget Password';
$lang['Copyright'] = 'JO-BD &copy; 2023. All Rights Reserved.';


?>

		