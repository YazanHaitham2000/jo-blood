<?php
/* 
------------------
Language: English
------------------
*/

$lang = array();

$lang['Title'] = 'نظام التبرع في الدم';

$lang['JO-BD'] = 'JO-BD';
$lang['Home'] = 'الرئيسية';
$lang['About_App'] = 'عن التطبيق';
$lang['Contact_Us'] = 'اتصل بنا';
$lang['Admin_Login'] = 'دخول مدير النظام';
$lang['Center_Login'] = 'دخول مدير مركز التبرع';
$lang['Welcome'] = 'اهلا وسهلا بكم في نظام التبرع في الدم';
$lang['Cutomer_Login'] = 'دخول المستخدمين';
$lang['Login_Info'] = 'الرجاء ادخال اسم المستخدم وكلمة المرور';
$lang['Login'] = 'دخول';
$lang['Signup'] = 'تسجيل جديد';
$lang['Forget_Password'] = 'هل نسيت كلمة المرور ؟';
$lang['Copyright'] = 'نظام التبرع في الدم. &copy; 2023. جميع الحقوق محفوظة';


?>

		