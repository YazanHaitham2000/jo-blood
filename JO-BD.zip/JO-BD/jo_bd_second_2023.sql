-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 14, 2023 at 09:41 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jo_bd_second_2023`
--

-- --------------------------------------------------------

--
-- Table structure for table `blood_centers`
--

CREATE TABLE `blood_centers` (
  `ID` int(20) NOT NULL,
  `Center_Name` varchar(250) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Center_Phone_Number` varchar(250) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Center_Longitude` varchar(250) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Center_Latitude` varchar(250) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Center_Address` varchar(250) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Center_Username` varchar(250) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Center_Password` varchar(250) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blood_centers`
--

INSERT INTO `blood_centers` (`ID`, `Center_Name`, `Center_Phone_Number`, `Center_Longitude`, `Center_Latitude`, `Center_Address`, `Center_Username`, `Center_Password`) VALUES
(1, 'King Hussein Medical Center', '+96265804804', '35.831088', '31.979273', 'King Hussein Medical Center, King Abdullah II St 230, Amman 11733, Jordan', 'test1', '123456789'),
(2, 'Jordan University Hospital', '+96265353666', '35.874534', '32.006856', 'Queen Rania St, Amman, Jordan', 'test2', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `ID` int(20) NOT NULL,
  `Category_Name` varchar(250) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`ID`, `Category_Name`) VALUES
(3, 'AB+'),
(5, 'AB-'),
(6, 'A+'),
(7, 'A-'),
(8, 'B+'),
(9, 'B-'),
(10, 'O+'),
(11, 'O-');

-- --------------------------------------------------------

--
-- Table structure for table `centers_stock`
--

CREATE TABLE `centers_stock` (
  `ID` int(20) NOT NULL,
  `Center_ID` int(20) NOT NULL,
  `Category_ID` int(20) NOT NULL,
  `Qnt` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `centers_stock`
--

INSERT INTO `centers_stock` (`ID`, `Center_ID`, `Category_ID`, `Qnt`) VALUES
(1, 1, 3, 10),
(2, 1, 5, 50),
(12, 1, 6, 0),
(13, 1, 7, 50),
(14, 1, 8, 5),
(15, 1, 9, 24),
(16, 1, 10, 15),
(17, 1, 11, 13),
(18, 2, 3, 13),
(19, 2, 5, 55),
(20, 2, 6, 128),
(21, 2, 7, 198),
(22, 2, 8, 147),
(23, 2, 9, 187),
(24, 2, 10, 135),
(25, 2, 11, 178);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `ID` int(20) NOT NULL,
  `Full_Name` varchar(250) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Email_Address` varchar(250) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Phone_Number` varchar(250) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Gender` varchar(250) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Category_ID` int(20) NOT NULL,
  `Availability_To_Donate` varchar(250) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Password` varchar(250) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Latitude` varchar(250) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Longitude` varchar(250) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Add_Date_Time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`ID`, `Full_Name`, `Email_Address`, `Phone_Number`, `Gender`, `Category_ID`, `Availability_To_Donate`, `Password`, `Latitude`, `Longitude`, `Add_Date_Time`) VALUES
(1, 'Ahmad', 'ahmad@live.com', '0790000000', 'Male', 3, 'Yes', '21232f297a57a5a743894a0e4a801fc3', '31.9453666', '35.9283716', '2023-04-27 22:28:49'),
(2, 'Ali', 'ali@live.com', '078000000', 'Male', 3, 'Yes', '21232f297a57a5a743894a0e4a801fc3', '', '', '2023-03-27 16:45:49'),
(3, 'Laila', 'laila@live.com', '077000000', 'Female', 6, 'Yes', '21232f297a57a5a743894a0e4a801fc3', '41.0361443', '28.985877700000003', '2023-04-27 22:32:31'),
(4, 'saleh', 'saleh@live.com', '0790000000', 'Male', 3, 'Yes', '21232f297a57a5a743894a0e4a801fc3', '41.0456091', '28.9922849', '2023-04-13 13:12:17'),
(5, 'musa', 'musa@live.com', '0780000000', 'Male', 5, 'Yes', '25f9e794323b453885f5181f1b624d0b', '41.0456091', '28.9922849', '2023-04-13 16:28:20');

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE `requests` (
  `ID` int(20) NOT NULL,
  `Customer_ID` int(20) NOT NULL,
  `Category_ID` int(20) NOT NULL,
  `Case_Description` varchar(250) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Case_Argent_Status` varchar(250) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Case_Qnt` int(20) NOT NULL,
  `Status` varchar(250) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Note` varchar(250) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Add_Date_Time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blood_centers`
--
ALTER TABLE `blood_centers`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `centers_stock`
--
ALTER TABLE `centers_stock`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Center_ID` (`Center_ID`),
  ADD KEY `Category_ID` (`Category_ID`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Category_ID` (`Category_ID`);

--
-- Indexes for table `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Category_ID` (`Category_ID`),
  ADD KEY `Customer_ID` (`Customer_ID`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blood_centers`
--
ALTER TABLE `blood_centers`
  MODIFY `ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `centers_stock`
--
ALTER TABLE `centers_stock`
  MODIFY `ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `requests`
--
ALTER TABLE `requests`
  MODIFY `ID` int(20) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `centers_stock`
--
ALTER TABLE `centers_stock`
  ADD CONSTRAINT `centers_stock_ibfk_1` FOREIGN KEY (`Center_ID`) REFERENCES `blood_centers` (`ID`),
  ADD CONSTRAINT `centers_stock_ibfk_2` FOREIGN KEY (`Category_ID`) REFERENCES `categories` (`ID`);

--
-- Constraints for table `customers`
--
ALTER TABLE `customers`
  ADD CONSTRAINT `customers_ibfk_1` FOREIGN KEY (`Category_ID`) REFERENCES `categories` (`ID`);

--
-- Constraints for table `requests`
--
ALTER TABLE `requests`
  ADD CONSTRAINT `requests_ibfk_1` FOREIGN KEY (`Customer_ID`) REFERENCES `customers` (`ID`),
  ADD CONSTRAINT `requests_ibfk_2` FOREIGN KEY (`Category_ID`) REFERENCES `categories` (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
