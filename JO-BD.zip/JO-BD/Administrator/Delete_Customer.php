<?php
session_start();

$ID=$_GET['ID'];

require_once('../includes/config.php');


mysqli_query($Conn,"delete from requests where Customer_ID='$ID'");
mysqli_query($Conn,"delete from customers where ID='$ID'");

	  
echo "<script language='JavaScript'>
			  alert ('Customer Has Been Deleted !');
      </script>";
	  

	echo "<script language='JavaScript'>
document.location='Customers.php';
        </script>";

?>