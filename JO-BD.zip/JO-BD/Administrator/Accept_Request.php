<?php
session_start();

$ID=$_GET['ID'];

require_once('../includes/config.php');


mysqli_query($Conn,"update requests set Status='Accept' where ID='$ID'");

	  
echo "<script language='JavaScript'>
			  alert ('Request Has Been Accepted !');
      </script>";
	  

	echo "<script language='JavaScript'>
document.location='Customers_Requests.php';
        </script>";

?>