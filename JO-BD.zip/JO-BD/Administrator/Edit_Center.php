<?php
session_start();

include("../includes/config.php"); 


$A_ID = $_SESSION['A_Log'];


if (!$_SESSION['A_Log'])
echo '<script language="JavaScript">
 document.location="../Admin_Login.php";
</script>';

$ID = $_GET['ID'];

$sql = mysqli_query($Conn,"select * from blood_centers where ID='$ID'");
$row = mysqli_fetch_array($sql);
$Center_Name = $row['Center_Name'];
$Center_Phone_Number = $row['Center_Phone_Number'];
$Center_Address = $row['Center_Address'];
$Center_Longitude = $row['Center_Longitude'];
$Center_Latitude = $row['Center_Latitude'];
$Center_Username = $row['Center_Username'];
$Center_Password = $row['Center_Password'];


if(isset($_POST['Submit']))
{
$ID = $_POST['ID'];
$Center_Name = $_POST['Center_Name'];
$Center_Phone_Number=$_POST['Center_Phone_Number'];
$Center_Address=$_POST['Center_Address'];
$Center_Username = $_POST['Center_Username'];
$Center_Password = $_POST['Center_Password'];

$Longitud = $_POST['long'];
$Latitude = $_POST['lat'];




$update = mysqli_query($Conn,"update blood_centers set Center_Name='$Center_Name', Center_Phone_Number='$Center_Phone_Number', Center_Address='$Center_Address', Center_Longitude='$Longitud', Center_Latitude='$Latitude', Center_Username='$Center_Username', Center_Password='$Center_Password' where ID='$ID'");


echo "<script language='JavaScript'>
alert ('Blood Center Information Has Been Updated Successfully !');
        </script>";


	echo "<script language='JavaScript'>
document.location='Blood_Centers.php';
        </script>";

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
   <!--
        ===
        This comment should NOT be removed.

        Charisma v2.0.0

        Copyright 2012-2014 Muhammad Usman
        Licensed under the Apache License v2.0
        http://www.apache.org/licenses/LICENSE-2.0

        http://usman.it
        http://twitter.com/halalit_usman
        ===
    -->
    <meta charset="utf-8">
        <title>JO-BD - Administration</title>
   <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- The styles -->
    <link id="bs-css" href="css/bootstrap-simplex.min.css" rel="stylesheet">

    <link href="css/charisma-app.css" rel="stylesheet">
    <link href='bower_components/fullcalendar/dist/fullcalendar.css' rel='stylesheet'>
    <link href='bower_components/fullcalendar/dist/fullcalendar.print.css' rel='stylesheet' media='print'>
    <link href='bower_components/chosen/chosen.min.css' rel='stylesheet'>
    <link href='bower_components/colorbox/example3/colorbox.css' rel='stylesheet'>
    <link href='bower_components/responsive-tables/responsive-tables.css' rel='stylesheet'>
    <link href='bower_components/bootstrap-tour/build/css/bootstrap-tour.min.css' rel='stylesheet'>
    <link href='css/jquery.noty.css' rel='stylesheet'>
    <link href='css/noty_theme_default.css' rel='stylesheet'>
    <link href='css/elfinder.min.css' rel='stylesheet'>
    <link href='css/elfinder.theme.css' rel='stylesheet'>
    <link href='css/jquery.iphone.toggle.css' rel='stylesheet'>
    <link href='css/uploadify.css' rel='stylesheet'>
    <link href='css/animate.min.css' rel='stylesheet'>

    <!-- jQuery -->
    <script src="bower_components/jquery/jquery.min.js"></script>

    <!-- The HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <!-- The fav icon -->
    <link rel="shortcut icon" href="img/icon.png"/>

 <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDemEmJPVUC9PoCzTLZLZdhwJLt5fu5XUc"></script>
    <script src="locationpicker.jquery.min.js"></script>


<style>
@font-face {
   font-family: myFirstFont;
   src: url(fonts/NotoKufiArabic-Regular.ttf);
   font-size:8px;
}
body {
   font-family: myFirstFont;
}

</style></head>

<body>
    <!-- topbar starts -->
    <div class="navbar navbar-default" role="navigation">

       <div class="navbar-inner">
            <button type="button" class="navbar-toggle pull-left animated flip">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                     </button>
 <a class="navbar-brand" href="index.php"> 
                <span>JO-Blood Donation Management System - Administrator Portal</span></a>

          

            <!-- user dropdown starts -->
            <div class="btn-group pull-right">
                <button class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                    <span class="hidden-sm hidden-xs"> Administrator Account</span>
                    <span class="caret"></span>
                </button>
                <ul class="dropdown-menu">
                   
                    <li><a href="Logout.php">Logout</a></li>
                </ul>
            </div>
            <!-- user dropdown ends -->

        
          

        </div>
    </div>
    <!-- topbar ends -->
<div class="ch-container">
    <div class="row">
        
        <!-- left menu starts -->
        <div class="col-sm-2 col-lg-2">
            <div class="sidebar-nav">
                <div class="nav-canvas">
                    <div class="nav-sm nav nav-stacked">

                    </div>
                    <ul class="nav nav-pills nav-stacked main-menu">
                        
                        <li><a class="ajax-link" href="index.php"><i class="glyphicon glyphicon-home-open"></i><span> Home</span></a>
                        </li>
                        <li ><a class="ajax-link" href="Categories.php"><i class="glyphicon glyphicon-list"></i><span> Categories</span></a>
                        </li>
                       
					    <li class="active"><a class="ajax-link" href="Blood_Centers.php"><i class="glyphicon glyphicon-list-open"></i><span> Blood Centers</span></a>
                        </li>
					   
					   
					   <li><a class="ajax-link" href="Customers.php"><i class="glyphicon glyphicon-user"></i><span> Customers</span></a>
                        </li>
						
					 
						
						
						
						 <li><a class="ajax-link" href="Customers_Requests.php"><i class="glyphicon glyphicon-user"></i><span> Customers Requests</span></a>
                        </li>
						
						
						
						 
						
						
						
                        <li><a href="Logout.php"><i class="glyphicon glyphicon-lock"></i><span> Logout</span></a>
						</li>


<li>
<center><img src="img/banner4.png" width="100%"/></center>
                        </li>


                    </ul>
                </div>
            </div>
        </div>
        <!--/span-->
        <!-- left menu ends -->

        

        <div id="content" class="col-lg-10 col-sm-10">
            <!-- content starts -->
            <div>
  
</div>


<div class="row">
    <div class="box col-md-12">
        <div class="box-inner">
            <div class="box-header well">
                <h2>Update Blood Center Information</h2>

                
            </div>
            <div class="box-content row">
                <div class="col-lg-12 col-md-12">
                    
					
		<form role="form" method="post" action="Edit_Center.php">
                            <input type="hidden" name="ID" value="<?php echo $ID; ?>"/>
							
                    <div class="form-group">
                        <label for="exampleInputEmail1">Center Name</label>
                        <input type="text" name="Center_Name" value="<?php echo $Center_Name; ?>" class="form-control" placeholder="Center Name" required>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Center Phone Number</label>
                        <input type="text" name="Center_Phone_Number" value="<?php echo $Center_Phone_Number; ?>" class="form-control" placeholder="Center Phone Number" required>
                    </div>
                  
				  <div class="form-group">
                        <label for="exampleInputPassword1">Center Address</label>
                        <input type="text" name="Center_Address" value="<?php echo $Center_Address; ?>" class="form-control" placeholder="Center Address" required>
                    </div>
					
					
					
					 <div class="form-group">
                        <label for="exampleInputPassword1">Center Username</label>
                        <input type="text" name="Center_Username" value="<?php echo $Center_Username; ?>" class="form-control" placeholder="Center Username" required>
                    </div>
					
					
					 <div class="form-group">
                        <label for="exampleInputPassword1">Center Password</label>
                        <input type="text" name="Center_Password" value="<?php echo $Center_Password; ?>" class="form-control" placeholder="Center Password" required>
                    </div>
					
					
					
					<div class="form-group">
                        <label for="exampleInputPassword1">Center Location</label>
 <input type="hidden" name="lat" class="form-control" style="width: 110px" id="us3-lat" required/>
                <input type="hidden" name="long" class="form-control" style="width: 110px" id="us3-lon" required />

  <div id="us3" style="height: 190px;"></div>
                                </div>
								
								
								  <script>
            $('#us3').locationpicker({
                location: {
                    latitude: <?php echo $Center_Latitude; ?>,
                    longitude: <?php echo $Center_Longitude; ?>

				},
                radius: 300,
                inputBinding: {
                    latitudeInput: $('#us3-lat'),
                    longitudeInput: $('#us3-lon'),
                    radiusInput: $('#us3-radius'),
                    locationNameInput: $('#us3-address')
                },
                enableAutocomplete: true,
                onchanged: function (currentLocation, radius, isMarkerDropped) {
                }
            });
        </script>

		
		
		
                                <div class="hr-line-dashed"></div>  





        
                        
        
      
                                
       


		

				
					
					
				  <button type="submit" name="Submit" class="btn btn-default">Edit</button> <button type="reset" class="btn btn-default">Clear</button>
                </form>
				   
				   
				   
				   
                </div>
                

            </div>
        </div>
    </div>
</div>



    <!-- content ends -->
    </div><!--/#content.col-md-0-->
</div><!--/fluid-row-->

    <!-- Ad, you can remove it -->
   

    <hr>

   

    <footer class="row">
        <center><p class="col-md-12 col-sm-12 col-xs-12 copyright">JO-BD © 2023. All Rights Reserved.</p></center>

      
    </footer>

</div><!--/.fluid-container-->

<!-- external javascript -->

<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

<!-- library for cookie management -->
<script src="js/jquery.cookie.js"></script>
<!-- calender plugin -->
<script src='bower_components/moment/min/moment.min.js'></script>
<script src='bower_components/fullcalendar/dist/fullcalendar.min.js'></script>
<!-- data table plugin -->
<script src='js/jquery.dataTables.min.js'></script>

<!-- select or dropdown enhancer -->
<script src="bower_components/chosen/chosen.jquery.min.js"></script>
<!-- plugin for gallery image view -->
<script src="bower_components/colorbox/jquery.colorbox-min.js"></script>
<!-- notification plugin -->
<script src="js/jquery.noty.js"></script>
<!-- library for making tables responsive -->
<script src="bower_components/responsive-tables/responsive-tables.js"></script>
<!-- tour plugin -->
<!-- star rating plugin -->
<script src="js/jquery.raty.min.js"></script>
<!-- for iOS style toggle switch -->
<script src="js/jquery.iphone.toggle.js"></script>
<!-- autogrowing textarea plugin -->
<script src="js/jquery.autogrow-textarea.js"></script>
<!-- multiple file upload plugin -->
<script src="js/jquery.uploadify-3.1.min.js"></script>
<!-- history.js for cross-browser state change on ajax -->
<script src="js/jquery.history.js"></script>
<!-- application script for Charisma demo -->
<script src="js/charisma.js"></script>



</body>
</html>
