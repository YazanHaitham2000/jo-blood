<?php
session_start();

$ID=$_GET['ID'];

require_once('../includes/config.php');


mysqli_query($Conn,"delete from blood_centers where ID='$ID'");
mysqli_query($Conn,"delete from centers_stock where Center_ID='$ID'");

	  
echo "<script language='JavaScript'>
			  alert ('Blood Center Has Been Deleted !');
      </script>";
	  

	echo "<script language='JavaScript'>
document.location='Blood_Centers.php';
        </script>";

?>